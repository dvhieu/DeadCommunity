#!/bin/bash

echo "facebook"
./el2bin ../DeadCommunity/data/facebookSSA.txt ../DeadCommunity/data/facebookSSA.bin
echo "wiki"
./el2bin ../DeadCommunity/data/wikiSSA.txt ../DeadCommunity/data/wikiSSA.bin
echo "epinions"
./el2bin ../DeadCommunity/data/epinionsSSA.txt ../DeadCommunity/data/epinionsSSA.bin
echo "dblp"
./el2bin ../DeadCommunity/data/dblpSSA.txt ../DeadCommunity/data/dblpSSA.bin
echo "pokec"
./el2bin ../DeadCommunity/data/pokecSSA.txt ../DeadCommunity/data/pokecSSA.bin
